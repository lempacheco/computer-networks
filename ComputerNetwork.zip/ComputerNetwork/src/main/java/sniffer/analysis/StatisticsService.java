package sniffer.analysis;

import sniffer.model.PacketInfo;

import java.util.HashMap;
import java.util.LongSummaryStatistics;
import java.util.Map;

public class StatisticsService {

    private long totalPackets = 0;
    private long totalBytes = 0;

    private Long firstPacketTimeMs = null;
    private Long lastPacketTimeMs = null;

    private long arpRequests = 0;
    private long arpReplies = 0;

    private final Map<String, Long> packetsByProtocol = new HashMap<>();
    private final Map<String, Long> bytesByProtocol = new HashMap<>();
    private final Map<String, Long> packetsBySourceIp = new HashMap<>();
    private final Map<String, Long> packetsByDestinationIp = new HashMap<>();

    private final Map<String, String> arpTable = new HashMap<>();

    private final Map<String, LongSummaryStatistics> rttByHostPair = new HashMap<>();

    public void register(PacketInfo info) {
        if (info == null) return;

        updateCaptureTimes();

        totalPackets++;
        totalBytes += info.getLength();

        String protocol = valueOrUnknown(info.getProtocol());
        packetsByProtocol.merge(protocol, 1L, Long::sum);
        bytesByProtocol.merge(protocol, (long) info.getLength(), Long::sum);

        if (info.getSrcIp() != null && !info.getSrcIp().isBlank())
            packetsBySourceIp.merge(info.getSrcIp(), 1L, Long::sum);

        if (info.getDstIp() != null && !info.getDstIp().isBlank())
            packetsByDestinationIp.merge(info.getDstIp(), 1L, Long::sum);

        if ("ARP".equalsIgnoreCase(protocol)) registerArp(info);
        if ("ICMP".equalsIgnoreCase(protocol) && info.getRtt() != null) registerIcmpRtt(info);
    }

    public void printSummary() {
        System.out.println();
        System.out.println("========== Capture summary ==========");
        System.out.println("Total packets: " + totalPackets);
        System.out.println("Total bytes: " + totalBytes);

        printDurationStats();
        printCountMap("Packets by protocol", packetsByProtocol, totalPackets);
        printCountMap("Bytes by protocol", bytesByProtocol, totalBytes);
        printMap("Top source IPs", packetsBySourceIp);
        printMap("Top destination IPs", packetsByDestinationIp);
        printArpStats();
        printIcmpRttStats();

        System.out.println("=====================================");
    }

    private void updateCaptureTimes() {
        long now = System.currentTimeMillis();
        if (firstPacketTimeMs == null) firstPacketTimeMs = now;
        lastPacketTimeMs = now;
    }

    private void printDurationStats() {
        if (firstPacketTimeMs == null || lastPacketTimeMs == null || totalPackets == 0) return;

        double durationSeconds = Math.max(0.001, (lastPacketTimeMs - firstPacketTimeMs) / 1000.0);
        System.out.printf("Capture duration: %.3f s%n", durationSeconds);
        System.out.printf("Packets/sec: %.2f%n", totalPackets / durationSeconds);
        System.out.printf("Bytes/sec: %.2f%n", totalBytes / durationSeconds);
        System.out.println();
    }

    private void printCountMap(String title, Map<String, Long> map, long total) {
        System.out.println(title + ":");

        if (map.isEmpty()) {
            System.out.println("  none");
            System.out.println();
            return;
        }

        map.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .forEach(entry -> {
                    double pct = total == 0 ? 0 : (entry.getValue() * 100.0) / total;
                    System.out.printf("  %s: %d (%.2f%%)%n", entry.getKey(), entry.getValue(), pct);
                });

        System.out.println();
    }

    private void printMap(String title, Map<String, Long> map) {
        System.out.println(title + ":");

        if (map.isEmpty()) {
            System.out.println("  none");
            System.out.println();
            return;
        }

        map.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(10)
                .forEach(entry -> System.out.println("  " + entry.getKey() + ": " + entry.getValue()));

        System.out.println();
    }

    private void registerArp(PacketInfo info) {
        if ("REQUEST".equalsIgnoreCase(info.getArpOperation())) {
            arpRequests++;
        } else if ("REPLY".equalsIgnoreCase(info.getArpOperation())) {
            arpReplies++;
        }

        if (isValidIp(info.getSrcIp()) && isValidMac(info.getSrcMac()))
            arpTable.put(info.getSrcIp(), info.getSrcMac());
    }

    private void printArpStats() {
        System.out.println("ARP statistics:");
        System.out.println("  Requests: " + arpRequests);
        System.out.println("  Replies: " + arpReplies);
        System.out.println();

        System.out.println("Observed ARP table (IP -> MAC):");

        if (arpTable.isEmpty()) {
            System.out.println("  none");
            System.out.println();
            return;
        }

        arpTable.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> System.out.println("  " + entry.getKey() + " -> " + entry.getValue()));

        System.out.println();
    }

    private void registerIcmpRtt(PacketInfo info) {
        if (!isValidIp(info.getSrcIp()) || !isValidIp(info.getDstIp())) return;

        String key = buildHostPairKey(info.getSrcIp(), info.getDstIp());
        rttByHostPair.computeIfAbsent(key, k -> new LongSummaryStatistics()).accept(info.getRtt());
    }

    private void printIcmpRttStats() {
        System.out.println("ICMP RTT statistics:");

        if (rttByHostPair.isEmpty()) {
            System.out.println("  none");
            System.out.println();
            return;
        }

        rttByHostPair.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    LongSummaryStatistics stats = entry.getValue();
                    System.out.printf("  %s: count=%d, avg=%.2f ms, min=%d ms, max=%d ms%n",
                            entry.getKey(), stats.getCount(), stats.getAverage(), stats.getMin(), stats.getMax());
                });

        System.out.println();
    }

    private String buildHostPairKey(String ipA, String ipB) {
        return ipA.compareTo(ipB) <= 0 ? ipA + " <-> " + ipB : ipB + " <-> " + ipA;
    }

    private String valueOrUnknown(String value) {
        return (value == null || value.isBlank()) ? "UNKNOWN" : value;
    }

    private boolean isValidIp(String ip) {
        return ip != null && !ip.isBlank() && !"0.0.0.0".equals(ip);
    }

    private boolean isValidMac(String mac) {
        return mac != null
                && !mac.isBlank()
                && !"00:00:00:00:00:00".equalsIgnoreCase(mac)
                && !"ff:ff:ff:ff:ff:ff".equalsIgnoreCase(mac);
    }
}
